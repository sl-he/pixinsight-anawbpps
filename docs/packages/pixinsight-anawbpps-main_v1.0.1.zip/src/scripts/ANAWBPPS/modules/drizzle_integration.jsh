/*
 * ANAWBPPS - DrizzleIntegration Module
 * Performs drizzle integration on registered images
 *
 * Copyright (C) 2024-2025 sl-he
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Repository: https://github.com/sl-he/pixinsight-anawbpps
 */

// ============================================================================
// Helpers
// ============================================================================

function DI_sanitizeKey(key){
    return String(key||"").replace(/[|:\\/\s]+/g, "_");
}

// ============================================================================
// Build Drizzle Suffix
// ============================================================================

function DI_buildDrizzleSuffix(scale){
    // scale = 1.0 → "_drz1x"
    // scale = 2.0 → "_drz2x"
    // scale = 3.0 → "_drz3x"
    var scaleInt = Math.round(scale);
    return "_drz" + scaleInt + "x";
}

// ============================================================================
// Build Simple SS Key (same as II)
// ============================================================================

function DI_buildSimpleSSKey(group){
    // Build simplified SS key: object|filter|exposure (NO setup, NO binning)
    var object = group.object || group.target || "UNKNOWN";
    var filter = group.filter || "L";
    var expTime = group.exposureSec || group.exposure || 0;

    return object + "|" + filter + "|" + expTime + "s";
}

// ============================================================================
// Collect and Group Files
// ============================================================================

function DI_collectAndGroupFiles(PLAN, workFolders){
    Console.writeln("[di] Collecting and grouping files...");
    
    if (!PLAN || !PLAN.groups){
        throw new Error("PLAN is empty (no groups)");
    }
    
    var diGroups = {}; // simpleSSKey -> { key, files, icGroups }
    
    // Iterate through all IC groups
    for (var icKey in PLAN.groups){
        if (!PLAN.groups.hasOwnProperty(icKey)) continue;
        
        var G = PLAN.groups[icKey];
        
        // Build simplified SS key
        var simpleSSKey = DI_buildSimpleSSKey(G);
        
        // Create DI group if not exists
        if (!diGroups[simpleSSKey]){
            diGroups[simpleSSKey] = {
                key: simpleSSKey,
                files: [],
                icGroups: [],
                bayerPattern: G.bayerPattern || null  // TODO-32: Store bayer pattern for CFA
            };
        }

        // Store IC group reference
        diGroups[simpleSSKey].icGroups.push(G);
        
        // Collect files from this IC group
        var bases = G.lights || [];

        // TODO-32: Check if group is CFA
        var isCFA = !!(G.bayerPattern);

        for (var i=0; i<bases.length; ++i){
            var basePath = bases[i];
            var stem = CU_noext(CU_basename(basePath));

            // TODO-32: CFA files have _d suffix after debayer
            var xdrzFile;
            if (isCFA){
                xdrzFile = workFolders.approvedSet + "/" + stem + "_c_cc_d_a_r.xdrz";
            } else {
                xdrzFile = workFolders.approvedSet + "/" + stem + "_c_cc_a_r.xdrz";
            }

            if (File.exists(xdrzFile)){
                diGroups[simpleSSKey].files.push(xdrzFile);
            } else {
                var suffix = isCFA ? "_c_cc_d_a_r.xdrz" : "_c_cc_a_r.xdrz";
                Console.warningln("[di]     File not found: " + stem + suffix);
            }
        }
    }

    // Find and add reference file for each DI group (using II_findReferenceForGroup)
    for (var ssKey in diGroups){
        if (!diGroups.hasOwnProperty(ssKey)) continue;

        var diGroup = diGroups[ssKey];

        if (diGroup.icGroups.length === 0){
            Console.warningln("[di] No IC groups for DI group: " + ssKey);
            continue;
        }

        // Use first IC group to find TOP-5 reference
        var firstICGroup = diGroup.icGroups[0];

        try{
            // Use II_findReferenceForGroup to get .xisf path, then convert to .xdrz
            var refXisf = II_findReferenceForGroup(ssKey, firstICGroup, workFolders);
            var refXdrz = refXisf.replace(/\.xisf$/, ".xdrz");

            // Validate .xdrz exists
            if (!File.exists(refXdrz)){
                Console.warningln("[di]   Reference drizzle data not found: " + refXdrz);
                continue;
            }

            // Check if reference is already in files list
            var refExists = false;
            for (var i=0; i<diGroup.files.length; ++i){
                if (CU_norm(diGroup.files[i]) === CU_norm(refXdrz)){
                    refExists = true;
                    break;
                }
            }

            if (!refExists){
                diGroup.files.push(refXdrz);
                Console.writeln("[di]   Added reference to files list: " + CU_basename(refXdrz));
            } else {
                Console.writeln("[di]   Reference already in files list");
            }
        }catch(e){
            Console.warningln("[di]   Failed to find reference: " + e);
        }
    }

    Console.writeln("[di] Grouped into " + Object.keys(diGroups).length + " DI group(s)");

    return diGroups;
}

// ============================================================================
// Build InputData Array
// ============================================================================

function DI_buildInputDataArray(files, useLN, workFolders){
    Console.writeln("[di]   Building inputData array...");
    
    var inputData = [];
    var skipped = [];
    
    for (var i=0; i<files.length; ++i){
        var xdrzPath = files[i];
        var xnmlPath = "";
        
        // If LN enabled, build .xnml path
        if (useLN){
            xnmlPath = xdrzPath.replace(/\.xdrz$/i, ".xnml");
            
            // Validate .xnml exists
            if (!File.exists(xnmlPath)){
                Console.warningln("[di]     LN data not found (skipping): " + CU_basename(xnmlPath));
                skipped.push(xdrzPath);
                continue;
            }
        }
        
        // Validate .xdrz exists
        if (!File.exists(xdrzPath)){
            Console.warningln("[di]     Drizzle data not found (skipping): " + CU_basename(xdrzPath));
            skipped.push(xdrzPath);
            continue;
        }
        
        // Add to inputData: [enabled, xdrzPath, xnmlPath]
        inputData.push([true, CU_norm(xdrzPath), CU_norm(xnmlPath)]);
    }
    
    if (skipped.length > 0){
        Console.writeln("[di]   Skipped " + skipped.length + " file(s) due to missing data");
    }
    
    Console.writeln("[di]   Total files: " + inputData.length);
    
    return inputData;
}

// ============================================================================
// Configure DrizzleIntegration Instance
// ============================================================================

function DI_configureInstance(P, inputData, useLN, scale, bayerPattern){
    // Set input data
    P.inputData = inputData;
    P.inputHints = "";
    P.inputDirectory = "";

    // Scale and kernel
    P.scale = scale;                                            // 1.0, 2.0, 3.0
    P.dropShrink = 0.90;                                        // Fixed
    P.kernelFunction = DrizzleIntegration.Kernel_Square;
    P.kernelGridSize = 16;
    P.originX = 0.50;
    P.originY = 0.50;

    // CFA (TODO-32: Enable for CFA groups)
    if (bayerPattern){
        P.enableCFA = true;
        P.cfaPattern = bayerPattern;  // "RGGB", "BGGR", "GBRG", "GRBG"
        Console.writeln("[di]   CFA enabled: " + bayerPattern);
    } else {
        P.enableCFA = false;
        P.cfaPattern = "";
    }
    
    // Main features
    P.enableRejection = true;
    P.enableImageWeighting = true;
    P.enableSurfaceSplines = true;
    P.enableLocalDistortion = true;
    
    // Normalization
    P.enableLocalNormalization = useLN;                         // true if LN enabled
    P.enableAdaptiveNormalization = false;
    
    // ROI
    P.useROI = false;
    P.roiX0 = 0;
    P.roiY0 = 0;
    P.roiX1 = 0;
    P.roiY1 = 0;
    
    // Output options
    P.closePreviousImages = false;
    P.useLUT = false;
    P.truncateOnOutOfRange = false;
    P.noGUIMessages = true;
    P.showImages = true;
    P.onError = DrizzleIntegration.Continue;
}

// ============================================================================
// Build Output Path
// ============================================================================

function DI_buildOutputPath(ssKey, fileCount, workFolders, scale, isWeights){
    // Parse ssKey: "object|filter|exposure"
    var parts = ssKey.split("|");
    var object = parts[0] || "UNKNOWN";
    var filter = parts[1] || "L";
    var exposure = parts[2] || "0s";
    
    // Sanitize object name
    var sanitizedObject = object.replace(/[\s|:\\/\.]+/g, "_");
    
    // Build drizzle suffix with scale: _drz1x, _drz2x, _drz3x
    var scaleInt = Math.round(scale);
    var drzSuffix = "_drz" + scaleInt + "x";
    
    // Add weights suffix if needed
    var suffix = isWeights ? (drzSuffix + "_weights") : drzSuffix;
    
    // Build filename: object_filter_COUNTxEXPOSURE_drz2x.xisf
    var filename = sanitizedObject + "_" + filter + "_" + fileCount + "x" + exposure + suffix + ".xisf";
    
    // Output folder: WORK2/!Integrated/
    var base = workFolders.base2 || workFolders.base1;
    var integratedFolder = base + "/!Integrated";
    
    // Create folder if not exists
    if (!File.directoryExists(integratedFolder)){
        File.createDirectory(integratedFolder, true);
        Console.writeln("[di]   Created folder: !Integrated");
    }
    
    var fullPath = CU_norm(integratedFolder + "/" + filename);
    
    return fullPath;
}

// ============================================================================
// Save Drizzle Results (2 files: drizzle + weights)
// ============================================================================

function DI_saveResults(drzView, weightsView, basePath, weightsPath, scale){
    Console.writeln("[di]   Saving results as 2 separate 32-bit files...");
    
    // Validate views
    if (!drzView || !drzView.image){
        throw new Error("Drizzle integration view is invalid");
    }
    if (!weightsView || !weightsView.image){
        throw new Error("Drizzle weights view is invalid");
    }
    
    try{
        var drzWindow = drzView.window;
        var weightsWindow = weightsView.window;
        
        // Save drizzle integration
        Console.writeln("[di]     Writing drizzle integration: " + CU_basename(basePath));
        if (!drzWindow.saveAs(basePath, false, false, true, false)){
            throw new Error("Failed to save drizzle integration");
        }
        
        // Save weights
        Console.writeln("[di]     Writing drizzle weights: " + CU_basename(weightsPath));
        if (!weightsWindow.saveAs(weightsPath, false, false, true, false)){
            throw new Error("Failed to save drizzle weights");
        }
        
        Console.writeln("[di]   ✓ Saved 2 files (32-bit float)");
        Console.writeln("[di]     Main:    " + CU_basename(basePath));
        Console.writeln("[di]     Weights: " + CU_basename(weightsPath));
        
    }catch(e){
        throw e;
    }
}

// ============================================================================
// Close Drizzle Views
// ============================================================================

function DI_closeViews(drzView, weightsView){
    Console.writeln("[di]   Closing views...");
    
    var closed = 0;
    
    try{
        if (drzView && drzView.window){
            drzView.window.forceClose();
            closed++;
        }
    }catch(e){
        Console.warningln("[di]     Failed to close drizzle view: " + e);
    }
    
    try{
        if (weightsView && weightsView.window){
            weightsView.window.forceClose();
            closed++;
        }
    }catch(e){
        Console.warningln("[di]     Failed to close weights view: " + e);
    }
    
    Console.writeln("[di]   ✓ Closed " + closed + " view(s)");
}

// ============================================================================
// Process One Group
// ============================================================================

function DI_processGroup(ssKey, diGroup, workFolders, useLN, scale, node){
    Console.writeln("[di] ========================================");
    Console.writeln("[di] Processing group: " + ssKey);
    Console.writeln("[di] ========================================");
    
    if (!diGroup.files || diGroup.files.length === 0){
        throw new Error("No files to drizzle for group: " + ssKey);
    }
    
    Console.writeln("[di]   Files: " + diGroup.files.length);
    Console.writeln("[di]   Scale: " + scale + "x");
    Console.writeln("[di]   LocalNormalization: " + (useLN ? "ENABLED" : "DISABLED"));
    Console.writeln("[di]   BayerPattern: " + (diGroup.bayerPattern || "none (mono)"));

    // Update UI - Running
    if (node){
        try{
            node.setText(3, "▶ Running");
            node.setText(4, "0/" + diGroup.files.length + " drizzling");
            if (typeof processEvents === "function") processEvents();
        }catch(_){}
    }

    // Build inputData array
    var inputData = DI_buildInputDataArray(diGroup.files, useLN, workFolders);

    if (inputData.length === 0){
        throw new Error("No valid files for drizzle integration: " + ssKey);
    }

    // Create DrizzleIntegration instance
    var P = new DrizzleIntegration;
    DI_configureInstance(P, inputData, useLN, scale, diGroup.bayerPattern);
    
    Console.writeln("[di]   Running DrizzleIntegration...");
    
    // Execute DrizzleIntegration
    var t0 = Date.now();
    var ok = true;
    try{
        P.executeGlobal();
    }catch(e){
        ok = false;
        Console.criticalln("[di]   DrizzleIntegration failed: " + e);
        throw e;
    }
    var elapsed = (Date.now() - t0) / 1000;
    
    Console.writeln("[di]   ✓ Completed in " + CU_fmtHMS(elapsed));
    
    // Save results
    try{
        Console.writeln("[di]   Processing results...");
        
        // Find views by standard IDs
        var drzView = View.viewById("drizzle_integration");
        var weightsView = View.viewById("drizzle_weights");
        
        if (!drzView){
            throw new Error("Drizzle view 'drizzle_integration' not found");
        }
        if (!weightsView){
            throw new Error("Weights view 'drizzle_weights' not found");
        }
        
        // Build output paths
        var basePath = DI_buildOutputPath(ssKey, inputData.length, workFolders, scale, false);
        var weightsPath = DI_buildOutputPath(ssKey, inputData.length, workFolders, scale, true);
        
        // Build view IDs with scale
        var baseName = CU_basename(basePath).replace(/\.xisf$/i, "");
        var weightsName = CU_basename(weightsPath).replace(/\.xisf$/i, "");
        
        // Rename views
        Console.writeln("[di]     Renaming views...");
        var oldDrzId = drzView.id;
        var oldWeightsId = weightsView.id;

        drzView.id = CU_sanitizeViewId(baseName, "DI");           // "Sivan_2_B_21x30s_drz2x"
        weightsView.id = CU_sanitizeViewId(weightsName, "DI");    // "Sivan_2_B_21x30s_drz2x_weights"
        
        Console.writeln("[di]       " + oldDrzId + " → " + drzView.id);
        Console.writeln("[di]       " + oldWeightsId + " → " + weightsView.id);
        
        // Save to files (32-bit Float)
        DI_saveResults(drzView, weightsView, basePath, weightsPath, scale);
        
        // Close views
        DI_closeViews(drzView, weightsView);
        
        Console.writeln("[di]   ✓ Results saved and views closed");
        
    }catch(e){
        Console.criticalln("[di]   Failed to save results: " + e);
        throw e;
    }
    
    // Update UI - Success
    if (node){
        try{
            node.setText(2, CU_fmtHMS(elapsed));
            node.setText(3, "✔ Success");
            node.setText(4, inputData.length + "/" + inputData.length + " drizzled");
            if (typeof processEvents === "function") processEvents();
        }catch(_){}
    }
}

// ============================================================================
// Main Entry Point
// ============================================================================

function DI_runForAllGroups(params){
    // params: { PLAN, workFolders, useLN, scale, dlg }
    var PLAN = params.PLAN;
    var workFolders = params.workFolders;
    var useLN = params.useLN || false;
    var scale = params.scale || 1.0;
    var dlg = params.dlg || null;

    Console.writeln("[di] ========================================");
    Console.writeln("[di] DrizzleIntegration: Processing all groups");
    Console.writeln("[di] ========================================");
    Console.writeln("[di] Scale: " + scale + "x");
    Console.writeln("[di] LocalNormalization: " + (useLN ? "ENABLED" : "DISABLED"));

    // Step 1: Collect and group files
    var diGroups = DI_collectAndGroupFiles(PLAN, workFolders);

    if (!diGroups || Object.keys(diGroups).length === 0){
        Console.warningln("[di] No groups found");
        return {totalProcessed: 0, totalSkipped: 0, groupNames: []};
    }

    // Step 2: Get group keys
    var groupKeys = [];
    for (var k in diGroups){
        if (diGroups.hasOwnProperty(k)) groupKeys.push(k);
    }

    Console.writeln("[di] Found " + groupKeys.length + " group(s)");

    // Step 3: PRE-CREATE all UI rows BEFORE processing
    var groupNodes = {};
    if (dlg){
        for (var i=0; i<groupKeys.length; ++i){
            var ssKey = groupKeys[i];
            var diGroup = diGroups[ssKey];
            
            // Parse key for label: "object | filter | exposure"
            var parts = ssKey.split("|");
            var object = parts[0] || "UNKNOWN";
            var filter = parts[1] || "L";
            var exposure = parts[2] || "0s";
            
            var scaleInt = Math.round(scale);
            var label = object + " | " + filter + " | " + exposure + " (" + diGroup.files.length + " subs, " + scaleInt + "x)";
            var node = dlg.addRow("DrizzleIntegration", label);
            
            try{
                node.setText(3, "⏳ Queued");
                node.setText(4, diGroup.files.length + "/" + diGroup.files.length + " queued");
            }catch(_){}
            
            groupNodes[ssKey] = node;
        }
        try{ if (typeof processEvents === "function") processEvents(); }catch(_){}
    }

    Console.writeln("[di] ========================================");

    // Step 4: Process each group
    for (var i=0; i<groupKeys.length; ++i){
        var ssKey = groupKeys[i];
        var diGroup = diGroups[ssKey];
        
        Console.writeln("[di] Group " + (i+1) + "/" + groupKeys.length + ": " + ssKey);
        
        try{
            var node = groupNodes[ssKey] || null;
            DI_processGroup(ssKey, diGroup, workFolders, useLN, scale, node);
        }catch(e){
            Console.criticalln("[di] ERROR processing group '" + ssKey + "': " + e);
            
            // Update UI - Error
            var node = groupNodes[ssKey];
            if (node){
                try{
                    node.setText(3, "✖ Error");
                    node.setText(4, "Failed: " + e);
                }catch(_){}
            }
            
            throw e;  // Stop entire script - operator must fix
        }
    }

    Console.writeln("[di] ========================================");
    Console.writeln("[di] DrizzleIntegration complete");
    Console.writeln("[di] ========================================");

    // Return statistics for notifications
    var totalProcessed = 0;
    var totalSkipped = 0;
    var groupNames = [];

    for (var i=0; i<groupKeys.length; ++i){
        var ssKey = groupKeys[i];
        var diGroup = diGroups[ssKey];
        totalProcessed += diGroup.files.length;
        groupNames.push(ssKey);
    }

    return {
        totalProcessed: totalProcessed,
        totalSkipped: totalSkipped,
        groupNames: groupNames
    };
}